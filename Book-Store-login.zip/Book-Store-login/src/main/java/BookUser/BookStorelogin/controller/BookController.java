package BookUser.BookStorelogin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import BookUser.BookStorelogin.model.Book;
import BookUser.BookStorelogin.model.User;
import BookUser.BookStorelogin.service.BookService;

@Controller

public class BookController {
	
	@Autowired
	private BookService bookservice;
	//method for displaying list of all books
	@GetMapping("/listbook")
	public String viewBookDataBase(Model model) {
		model.addAttribute("listBooks",bookservice.getAllBooks());
		return "listbooks";
	}
	@GetMapping("/showNewBookForm")
	public String showNewBookForm(Model model) {
	Book book = new Book();
		model.addAttribute("book",book);
		return "new_book";
	}
	//saveBook
	@PostMapping("/saveBook")
	public String saveBook(@ModelAttribute("book") Book book) {
		
		bookservice.saveBook(book);
		return "redirect:/listbook";
		
	}
	//showBookUpdate
	@GetMapping("/showBookUpdate/{id}")
	public String showBookUpdate(@PathVariable(value="id") long id, Model model) {
		
		Book book = bookservice.getBookById(id);
		model.addAttribute("book",book);
		return "update_book";
		
	}
	
	//deleteBook
	@GetMapping("/deleteBook/{id}")
	public String deleteBook(@PathVariable(value="id") long id, Model model) {
		this.bookservice.deleteBook(id);
		return "redirect:/listbook";
		
		
		
	}
	@GetMapping("/login")
	public String login(Model model) {
		User user  = new User();
		model.addAttribute(user);
		return "login";
	}
	@PostMapping("/userlogin")
	public String loginuser(@ModelAttribute("user") User user) {
		
		System.out.println(user.getPassword_entered());
		return "login";
	}

}
