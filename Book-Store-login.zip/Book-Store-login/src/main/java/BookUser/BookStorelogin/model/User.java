package BookUser.BookStorelogin.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="user_id")
	private String user_id;
	@Column(name="password_entered")
	private String password_entered;
	
	public User() {
		
	}
	public User(Long id, String user_id, String password_entered) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.password_entered = password_entered;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getPassword_entered() {
		return password_entered;
	}

	public void setPassword_entered(String password_entered) {
		this.password_entered = password_entered;
	}
	
}
