package BookUser.BookStorelogin.model;

public class UserSave {

}
