package BookUser.BookStorelogin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import BookUser.BookStorelogin.model.Book;

public interface BookService {
	List<Book> getAllBooks();
	void saveBook(Book book);
	Book getBookById(long id);
	//deletemethod
	public void deleteBook(long id);
	

}
