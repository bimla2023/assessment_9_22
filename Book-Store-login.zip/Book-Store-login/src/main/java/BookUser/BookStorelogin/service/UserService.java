package BookUser.BookStorelogin.service;

public interface UserService {

}
