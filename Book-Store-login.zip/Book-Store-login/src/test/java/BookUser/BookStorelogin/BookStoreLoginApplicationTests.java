package BookUser.BookStorelogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
